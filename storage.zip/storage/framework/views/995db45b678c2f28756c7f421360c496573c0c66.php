<footer class="main-footer">
    <strong>Copyright &copy; 2023-2030 <a href="https://fouraxiz.com/" target="_blank">4axiz IT LTD.</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.2.0
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\hr_payroll\resources\views/inc/footer.blade.php ENDPATH**/ ?>